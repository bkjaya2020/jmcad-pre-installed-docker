JMCAD is an program for the modeling and simulation of complex dynamic systems. This includes the ability to construct and simulate block diagrams. The visual lock diagram interface offers a simple method for constructing, modifying and maintaining complex system models. The simulation engine provides fast and accurate solutions for linear, nonlinear, continuous time, discrete time, time varying and hybrid system designs. With JMCAD, users can quickly develop software or "virtual" prototypes of systems or processes to demonstrate their behavior prior to building physical prototypes.

By combining the simplicity and clarity of a block diagram interface with a high-performance mathematical engine, JMCAD provides fast and accurate solutions for linear, nonlinear, continuous time, discrete time, multi-rate, and hybrid systems. Moreover, JMCAD's tightly integrated development platform makes it easy to pass freely between model construction, simulation, optimization, and validation. This lets you create virtual prototypes on your desktop to make sure your design works properly before committing to prototype. For specialized engineering problems, JMCAD offers a comprehensive set of companion products for frequency domain analysis, Java code generation, communications system modeling, DSP and embedded system design, neural networks and real-time analog and digital I/O. The program is developed with use of language Java and can be used in various operational systems (Windows, Linux, Solaris, Unix, etc.).

JMCAD written completely in Java (Java SE) and will run in any certified Java Virtual Machine (JVM).

http://jmcad.sourceforge.net/ 

Installation JMCAD from Java Web Start
--------------------------------------
1) You need to install the following to get started with JMCAD a Java Engine http://java.com/
2) Launching the application JMCAD from Java Web Start online at http://jmcad.sf.net/
 

Installation and useful commands to run
---------------------------------------
1) You need to install the following to get started with JMCAD a Java Engine (Java SE) - http://java.sun.com/javase/downloads/  You can take either the Runtime environment (JRE) or the Development Kit (SDK).
2) Download JMCAD Engine - http://sourceforge.net/project/platformdownload.php?group_id=216987
3) To run the program from the bash file:
	Windows: __JMCAD.XXXXX.bat
	Linux/Unix: __JMCAD.XXXXX.sh
	
