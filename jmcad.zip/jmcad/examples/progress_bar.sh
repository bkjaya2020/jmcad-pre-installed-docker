#!/bin/sh
java  -Xmx500m -classpath .:$CLASSPATH:../JMCAD.jar:../lib/LogDB.jar:../lib/mysql-connector-java-5.1.11-bin.jar JMCAD -single progress_bar.jmcad

