#!/bin/sh

java  -Xmx500m -Djava.library.path="lib/sparc-sun-solaris2.10" -classpath .:$CLASSPATH:lib/LogDB.jar:lib/mysql-connector-java-5.1.11-bin.jar:lib/RXTXcomm.jar:lib/JOCL-0.1.7.jar:lib/JMCAD_install.jar:JMCAD.jar JMCAD

