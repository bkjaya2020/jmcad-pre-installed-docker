#!/bin/sh
java  -Xmx500m -classpath .:$CLASSPATH:../JMCADRTS.jar:../lib/LogDB.jar:../lib/mysql-connector-java-5.1.11-bin.jar JMCADRTS control.jmcad

