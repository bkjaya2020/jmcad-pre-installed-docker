#!/bin/sh
java  -Xmx500m -classpath .:$CLASSPATH:../JMCADRTC.jar:../lib/LogDB.jar:../lib/mysql-connector-java-5.1.11-bin.jar JMCADRTC convert_double_value_to_8_bit.jmcad

